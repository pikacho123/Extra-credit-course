<?php
/*$con = pg_connect("host=192.168.16.252 dbname=BG28 user=BG28 password=");*/
$con = pg_connect("host=localhost dbname=BG28 user=postgres password=admin123");
 ?>
