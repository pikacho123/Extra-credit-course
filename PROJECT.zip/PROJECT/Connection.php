<?php


$conn=pg_connect("host=localhost user=postgres dbname=BG20 password='1234'");
/*if(!$conn){
	echo "Not connected";
}
else
{
	echo "connected";
}*/

?>
 
